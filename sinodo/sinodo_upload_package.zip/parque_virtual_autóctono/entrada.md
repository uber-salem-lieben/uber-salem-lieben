# Entrada Oficial al Parque Virtual Autóctono
Mapa, rituales, bienvenida y nodo de huellas simbióticas.